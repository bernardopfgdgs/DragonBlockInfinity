package com.dragonblockinfinity.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class MenuInicial extends Screen {
    
    // ========== TEXTURAS ==========
    private static final ResourceLocation MENU_TEXTURE = 
        new ResourceLocation("dragonblockinfinity", "textures/gui/menu_base.png");
    
    private static final ResourceLocation ICONS_TEXTURE = 
        new ResourceLocation("dragonblockinfinity", "textures/gui/icons_btn.png");
    
    // ========== TAMANHOS DA GUI ==========
    private static final int GUI_WIDTH = 256;
    private static final int GUI_HEIGHT = 200;
    
    // ========== TAMANHOS DOS ÍCONES ==========
    private static final int ICON_SIZE = 32;
    private static final int ICON_TEX_WIDTH = 768;
    private static final int ICON_TEX_HEIGHT = 768;
    
    // ========== POSIÇÃO DA GUI ==========
    private int guiX;
    private int guiY;
    
    // ========== BOTÕES ==========
    private Botao[] botoes;
    private int botaoHover = -1; // Qual botão o mouse tá em cima (-1 = nenhum)
    
    public MenuInicial() {
        super(Component.literal("Menu Inicial"));
    }
    
    @Override
    protected void init() {
        super.init();
        
        // Centraliza a GUI na tela
        this.guiX = (this.width - GUI_WIDTH) / 2;
        this.guiY = (this.height - GUI_HEIGHT) / 2;
        
        // Cria os botões
        this.botoes = new Botao[] {
            // Botão 1 - Skills
            new Botao(
                guiX + 10, guiY + 10,  // Posição na tela
                0, 0,                   // Posição na textura (u, v)
                "Skills"                // Nome
            ),
            
            // Botão 2 - Stats
            new Botao(
                guiX + 50, guiY + 10,   // 40 pixels pra direita do botão 1
                33, 0,                   // Segunda coluna da textura
                "Stats"
            ),
            
            // Botão 3 - Transformations
            new Botao(
                guiX + 90, guiY + 10,
                66, 0,                   // Terceira coluna da textura
                "Transformações"
            ),
            
            // Botão 4 - Techniques (linha de baixo)
            new Botao(
                guiX + 10, guiY + 50,
                0, 33,                   // Segunda linha da textura
                "Técnicas"
            ),
            
            // Botão 5 - Config
            new Botao(
                guiX + 50, guiY + 50,
                33, 33,
                "Config"
            )
        };
    }
    
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Fundo escuro
        this.renderBackground(guiGraphics);
        
        // Desenha o fundo do menu
        RenderSystem.setShaderTexture(0, MENU_TEXTURE);
        guiGraphics.blit(
            MENU_TEXTURE,
            guiX, guiY,              // Onde desenhar na tela
            0, 0,                    // Onde pegar da textura
            GUI_WIDTH, GUI_HEIGHT,   // Tamanho
            GUI_WIDTH, GUI_HEIGHT    // Tamanho da textura
        );
        
        // Desenha todos os botões
        RenderSystem.setShaderTexture(0, ICONS_TEXTURE);
        botaoHover = -1; // Reseta qual botão tá com hover
        
        for (int i = 0; i < botoes.length; i++) {
            Botao btn = botoes[i];
            
            // Verifica se o mouse tá em cima deste botão
            boolean hover = mouseX >= btn.x && mouseX <= btn.x + ICON_SIZE &&
                           mouseY >= btn.y && mouseY <= btn.y + ICON_SIZE;
            
            if (hover) {
                botaoHover = i;
                // Desenha um fundo branco atrás quando hover
                guiGraphics.fill(btn.x - 2, btn.y - 2, btn.x + ICON_SIZE + 2, btn.y + ICON_SIZE + 2, 0xFFFFFFFF);
            }
            
            // Desenha o ícone do botão
            guiGraphics.blit(
                ICONS_TEXTURE,
                btn.x, btn.y,            // Posição na tela
                btn.u, btn.v,            // Posição na textura de ícones
                ICON_SIZE, ICON_SIZE,    // Tamanho do ícone
                ICON_TEX_WIDTH, ICON_TEX_HEIGHT
            );
            
            // Se hover, desenha o nome do botão
            if (hover) {
                guiGraphics.drawString(
                    this.font, 
                    btn.nome, 
                    mouseX + 10, 
                    mouseY - 10, 
                    0xFFFFFF
                );
            }
        }
        
        // Título do menu
        guiGraphics.drawCenteredString(
            this.font,
            "Menu Principal",
            guiX + (GUI_WIDTH / 2),
            guiY + 5,
            0xFFFFFF
        );
        
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Detecta clique nos botões
        if (button == 0) { // Botão esquerdo do mouse
            for (int i = 0; i < botoes.length; i++) {
                Botao btn = botoes[i];
                
                // Verifica se clicou dentro do botão
                if (mouseX >= btn.x && mouseX <= btn.x + ICON_SIZE &&
                    mouseY >= btn.y && mouseY <= btn.y + ICON_SIZE) {
                    
                    aoClicarBotao(i);
                    return true;
                }
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    private void aoClicarBotao(int id) {
        // Aqui você faz o que acontece quando clica em cada botão
        Minecraft mc = Minecraft.getInstance();
        
        switch (id) {
            case 0: // Skills
                if (mc.player != null) {
                    mc.player.sendSystemMessage(Component.literal("Abrindo Skills..."));
                }
                // mc.setScreen(new TelaSkills());
                break;
                
            case 1: // Stats
                if (mc.player != null) {
                    mc.player.sendSystemMessage(Component.literal("Abrindo Stats..."));
                }
                break;
                
            case 2: // Transformações
                if (mc.player != null) {
                    mc.player.sendSystemMessage(Component.literal("Abrindo Transformações..."));
                }
                break;
                
            case 3: // Técnicas
                if (mc.player != null) {
                    mc.player.sendSystemMessage(Component.literal("Abrindo Técnicas..."));
                }
                break;
                
            case 4: // Config
                this.onClose(); // Fecha o menu
                break;
        }
    }
    
    @Override
    public boolean isPauseScreen() {
        return false; // false = não pausa o jogo quando abre
    }
    
    // ========== CLASSE INTERNA PRA GUARDAR INFO DO BOTÃO ==========
    private static class Botao {
        int x, y;      // Posição na tela
        int u, v;      // Posição na textura
        String nome;   // Nome do botão
        
        Botao(int x, int y, int u, int v, String nome) {
            this.x = x;
            this.y = y;
            this.u = u;
            this.v = v;
            this.nome = nome;
        }
    }
}
