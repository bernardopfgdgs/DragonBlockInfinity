package com.dragonblockinfinity.common.stats;

public class Spirit {
    private double maxKi;

    public Spirit(double maxKi) {
        this.maxKi = maxKi;
    }

    public double getMaxKi() {
        return maxKi;
    }

    public void setMaxKi(double maxKi) {
        this.maxKi = maxKi;
    }
}