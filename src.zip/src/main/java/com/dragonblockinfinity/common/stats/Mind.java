package com.dragonblockinfinity.common.stats;

public class Mind {
    private double skillPoints;

    public Mind(double skillPoints) {
        this.skillPoints = skillPoints;
    }

    public double getSkillPoints() {
        return skillPoints;
    }

    public void setSkillPoints(double skillPoints) {
        this.skillPoints = skillPoints;
    }
}