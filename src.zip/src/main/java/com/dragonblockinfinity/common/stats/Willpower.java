package com.dragonblockinfinity.common.stats;

public class Willpower {
    private double kiAttackPower;

    public Willpower(double kiAttackPower) {
        this.kiAttackPower = kiAttackPower;
    }

    public double getKiAttackPower() {
        return kiAttackPower;
    }

    public void setKiAttackPower(double kiAttackPower) {
        this.kiAttackPower = kiAttackPower;
    }
}